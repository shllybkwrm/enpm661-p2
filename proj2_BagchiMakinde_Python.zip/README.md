# enpm661-p2
ENPM661, Planning for Autonomous Robots, Spring 2020.  Project 2, Shelly Bagchi &amp; Omololu Makinde

Dependencies:  NumPy, OpenCV
Use "pip install opencv-python" to install OpenCV 